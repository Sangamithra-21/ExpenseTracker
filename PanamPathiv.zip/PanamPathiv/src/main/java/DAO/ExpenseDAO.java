package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExpenseDAO extends ParentDAO {

    public boolean addExpense(int userId, int categoryId, String date, String amount, String description) throws SQLException {
        
        String query = "INSERT INTO EXPENSE (UserID, CategoryID, Date, Amount, Description) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, userId);
            ps.setInt(2, categoryId); 
            ps.setString(3, date);
            ps.setString(4, amount);
            ps.setString(5, description);  

            int result = ps.executeUpdate();
            return result > 0;
        }
    }

    public List<Map<String, Object>> getExpanseList(int userId, String date) throws SQLException {
        List<Map<String, Object>> expenseList = new ArrayList<>();

        String query = "SELECT e.ExpenseID, c.CategoryName, e.Amount " +
                       "FROM EXPENSE e " +
                       "JOIN CATEGORY c ON e.CategoryID = c.CategoryID " +
                       "WHERE e.UserID = ? AND e.Date = ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, userId);
            ps.setString(2, date);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> expense = new HashMap<>();
                    expense.put("id", rs.getInt("ExpenseID"));
                    expense.put("cname", rs.getString("CategoryName"));
                    expense.put("amount", rs.getBigDecimal("Amount"));
                    expenseList.add(expense);
                }
            }
        }
        return expenseList;
    }

	public boolean deleteExpenseById(int id) throws SQLException {
		
		String query = "DELETE FROM EXPENSE WHERE ExpenseID = ?";
		
		try(PreparedStatement ps = connection.prepareStatement(query))
		{
			ps.setInt(1, id);
			int result = ps.executeUpdate();
			return result>0;
		}
		
	}
	
}
