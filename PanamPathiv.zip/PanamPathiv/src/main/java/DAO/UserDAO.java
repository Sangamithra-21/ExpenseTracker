package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO extends ParentDAO {

	public int getUserIdByEmail(String email) throws SQLException {
		
		String query = "SELECT userID FROM USER WHERE emailid= ?";
		
		try(PreparedStatement ps = connection.prepareStatement(query))
		{
			ps.setString(1,email);
			try(ResultSet rs = ps.executeQuery())
			{
				if(rs.next())
				{
					return rs.getInt("userID");
				}else
				{
					throw new SQLException("User not Found");
				}
			}
			
		}		
		
		

	}
	
	

}
