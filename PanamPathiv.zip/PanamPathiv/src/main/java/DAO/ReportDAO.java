package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReportDAO extends ParentDAO {

    public List<Map<String, Object>> getExpenseData(int userId, String fromDate, String toDate) throws SQLException {
        
        List<Map<String, Object>> expenseData = new ArrayList<>();
        
        String query = "SELECT e.ExpenseID, c.CategoryName, e.Amount, e.Date " +
                       "FROM EXPENSE e " +
                       "JOIN CATEGORY c ON e.CategoryID = c.CategoryID " +
                       "WHERE e.UserID = ? " +
                       "AND e.Date BETWEEN ? AND ?";

        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, userId);
            ps.setDate(2, java.sql.Date.valueOf(fromDate)); 
            ps.setDate(3, java.sql.Date.valueOf(toDate)); 

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Map<String, Object> expense = new HashMap<>();
                    expense.put("date", rs.getDate("Date")); 
                    expense.put("cname", rs.getString("CategoryName"));
                    expense.put("amount", rs.getBigDecimal("Amount"));
                    
                    expenseData.add(expense);
                }
            }
        }
        return expenseData;
    }
}
