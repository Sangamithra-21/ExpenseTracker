package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SignupDAO extends ParentDAO implements Password {

	public boolean addUser(String username, String password, String mobile, String emailid) throws SQLException {
		 System.out.println("Mobile: " + mobile); 
		if(isEmailExist(emailid) || isMobileExist(mobile))
		{
			return false;
			
		}
		
		String hashedPassword = hashPassword(password);
		String query = "INSERT INTO USER(username,phone_number,emailid,password) VALUES (?,?,?,?)";
		
		try(PreparedStatement ps = connection.prepareStatement(query)) 
		{
			ps.setString(1, username);
			ps.setString(2, mobile);
			ps.setString(3, emailid);
			ps.setString(4, hashedPassword);
			ps.executeUpdate();
		}
		return true;
	

}

	private boolean isMobileExist(String mobile) throws SQLException {
		String query = "SELECT COUNT(*) FROM USER WHERE phone_number=?";
		try(PreparedStatement ps = connection.prepareStatement(query))
		{
			ps.setString(1, mobile);
			ResultSet rs = ps.executeQuery();
			if(rs.next() && rs.getInt(1)>0)
			{
				return true;
			}
		}
		return false;
	}

	private boolean isEmailExist(String emailid) throws SQLException {
		String query = "SELECT COUNT(*) FROM USER WHERE emailid=?";
		try(PreparedStatement ps = connection.prepareStatement(query))
		{
			ps.setString(1, emailid);
			ResultSet rs = ps.executeQuery();
			if(rs.next() && rs.getInt(1)>0)
			{
				return true;
			}
		}
		return false;
	}

}
