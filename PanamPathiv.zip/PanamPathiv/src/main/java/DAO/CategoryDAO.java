package DAO;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;


public class CategoryDAO extends ParentDAO {

	public int getCategoryByName(String category) throws SQLException {
		
		String query = "SELECT CategoryID FROM CATEGORY WHERE CategoryName = ?";
		
		try(PreparedStatement ps = connection.prepareStatement(query))
		{
			ps.setString(1, category);
			try(ResultSet rs = ps.executeQuery())
			{
				if(rs.next())
				{
					return rs.getInt("CategoryID");
				}
				else
				{
					throw new SQLException("Item not Found");
				}
			}
		}
	}
	
	

}
