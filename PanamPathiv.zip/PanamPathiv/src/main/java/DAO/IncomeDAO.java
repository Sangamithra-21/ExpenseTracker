package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IncomeDAO extends ParentDAO{

	public boolean addIncome(int userId, String date, String amount, String source) throws SQLException {
		
		
		String query = "INSERT INTO INCOME(UserID,Date,Amount,Description) VALUES (?,?,?,?)";
		try(PreparedStatement ps = connection.prepareStatement(query))
		{
			ps.setInt(1, userId);
			ps.setString(2, date);
			ps.setString(3, amount);
			ps.setString(4, source);
			
			int result = ps.executeUpdate();
			return result>0;
		}
		
	}

	public List<Map<String, Object>> getIncomeList(int userId, String date) throws SQLException {
		
		List<Map<String,Object>> incomeList = new ArrayList<>();
		
		String query = "SELECT IncomeID,Amount,Description FROM INCOME WHERE UserID =? AND DATE = ? ";
		
		try(PreparedStatement ps = connection.prepareStatement(query))
		{
			ps.setInt(1, userId);
			ps.setString(2, date);
			
			try(ResultSet rs = ps.executeQuery())
			{
				while(rs.next())
				{
					Map<String,Object> income = new HashMap<>();
					income.put("id",rs.getInt("IncomeID"));
					income.put("amount", rs.getString("Amount"));
					income.put("source", rs.getString("Description"));
					incomeList.add(income);
				}
			}
		}
		
		return incomeList;
	}

	public boolean deleteIncome(String incomeId) throws SQLException {
		 
		
		String query = "DELETE FROM INCOME WHERE IncomeID = ?";
		
		try(PreparedStatement ps = connection.prepareStatement(query))
		{
			ps.setString(1, incomeId);
			
			
			int res = ps.executeUpdate();
			return res>0;
		}
		
	}

}
