package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDAO extends ParentDAO implements Password{

	public boolean verifyUser(String password, String email) throws SQLException {
		password = hashPassword(password);
		String query = "SELECT * FROM USER WHERE emailid = ? AND password = ?";
		try (PreparedStatement ps = connection.prepareStatement(query)) {
			ps.setString(1, email);
			ps.setString(2, password);
			try (ResultSet rs = ps.executeQuery()) {
				
				return rs.next(); 
			}
		}
	}
}




