package ExpenseTracker;

import java.io.IOException;
import java.sql.SQLException;

import DAO.ExpenseDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/deleteExpense")
public class DeleteExpenseServlet extends HttpServlet{
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		HttpSession session = request.getSession();
		String email =(String) session.getAttribute("emailid");
		
		String exId = request.getParameter("id");
		int id = Integer.parseInt(exId);
		
		
		ExpenseDAO expenseDao = new ExpenseDAO();
		
		try {
			boolean isDeleted = expenseDao.deleteExpenseById(id);
			
			if(isDeleted)
			{
				response.sendRedirect("dashboard.jsp");
			}
		} catch (SQLException e) {
			
			response.sendRedirect("delete_expense.jsp");
			e.printStackTrace();
		}
			
		
	}
	

}
