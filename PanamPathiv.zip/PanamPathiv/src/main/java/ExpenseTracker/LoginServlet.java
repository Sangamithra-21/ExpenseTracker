package ExpenseTracker;

import java.io.IOException;

import DAO.LoginDAO;
import DAO.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = request.getParameter("emailid");
		String password = request.getParameter("password");
		
		
		try {
			if (new LoginDAO().verifyUser(password, email)) {
				
				
				HttpSession session = request.getSession();
				session.setAttribute("emailid", email); 
			
			
				response.sendRedirect("dashboard.jsp");
			} else {
			
				request.setAttribute("errorMessage", "Login failed. Invalid credentials.");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
