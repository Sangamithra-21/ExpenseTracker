package ExpenseTracker;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import DAO.UserDAO;
import DAO.ReportDAO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/fetchReport")
public class FetchReportServlet extends HttpServlet {
  
	private static final long serialVersionUID = 1L;
	
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
    	
    	 HttpSession session = request.getSession();
         String email = (String) session.getAttribute("emailid");
         
         
        String fromDate = request.getParameter("fromDate");
        String toDate = request.getParameter("toDate");
        
    
        
        
        
        try {
            int userId = new UserDAO().getUserIdByEmail(email);
            
            List<Map<String, Object>> expenseList = new ReportDAO().getExpenseData(userId, fromDate, toDate);
            
            request.setAttribute("expenseList", expenseList);
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("final_report.jsp");
            dispatcher.forward(request, response);
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
