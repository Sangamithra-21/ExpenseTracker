package ExpenseTracker;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import DAO.IncomeDAO;
import DAO.UserDAO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/fetchIncome")
public class FetchIncomeServlet extends HttpServlet{
	
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
		
		HttpSession session = request.getSession();
		String email = (String)session.getAttribute("emailid");
		
		String date = (String)request.getParameter("date");
		
		try {
			int userId = new UserDAO().getUserIdByEmail(email);
			
			IncomeDAO incomeDao = new IncomeDAO();
			
			List<Map<String,Object>> incomeList = incomeDao.getIncomeList(userId,date);
			
			request.setAttribute("incomeList", incomeList);
            request.setAttribute("selectedDate", date);
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("displayIncome.jsp");
            dispatcher.forward(request, response);
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			
		}
		
	}
	

}
