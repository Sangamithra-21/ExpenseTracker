package ExpenseTracker;

import java.io.IOException;

import java.sql.SQLException;

import DAO.IncomeDAO;
import DAO.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;



@WebServlet("/addIncome")
public class AddIncomeServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException
	{
		String date = request.getParameter("date");
		String amount = request.getParameter("amount");
		String source = request.getParameter("source");
		
		
		HttpSession session = request.getSession();
		String email = (String) session.getAttribute("emailid");
		
		try {
			
			
			UserDAO userDao = new UserDAO();
			int userId = userDao.getUserIdByEmail(email);
			
			
			IncomeDAO incomeDao = new IncomeDAO();
			boolean isInserted = incomeDao.addIncome(userId,date,amount,source);
			if(isInserted)
			{
				response.sendRedirect("dashboard.jsp");
			}
			else
			{
				request.setAttribute("errorMessage", "Failed to add income, please try again.");
				request.getRequestDispatcher("add_income.jsp").forward(request, response);
			}
			
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			request.setAttribute("errorMessage", "Failed to add income, please try again.");
			request.getRequestDispatcher("add_income.jsp").forward(request, response);

			
		}
		
	}

}
