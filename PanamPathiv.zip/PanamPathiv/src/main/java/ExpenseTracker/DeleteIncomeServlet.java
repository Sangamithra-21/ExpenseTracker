package ExpenseTracker;

import java.io.IOException;
import java.sql.SQLException;

import DAO.IncomeDAO;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/deleteIncome")
public class DeleteIncomeServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		HttpSession session = request.getSession();
		String email = (String) request.getParameter("emailid");
		
		String incomeId = request.getParameter("id");
		
		IncomeDAO incomeDao = new IncomeDAO();
		
		try {
			boolean isDeleted = incomeDao.deleteIncome(incomeId);
			
			if(isDeleted)
			{
				response.sendRedirect("delete_income.jsp");
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
			response.sendRedirect("delete_income.jsp");
		}
	     
		
	   
		
	}

}
