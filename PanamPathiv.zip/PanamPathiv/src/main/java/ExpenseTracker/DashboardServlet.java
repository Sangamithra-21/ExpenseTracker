package ExpenseTracker;

import java.io.IOException;
import java.sql.SQLException;

import java.util.Map;

import DAO.DashboardDAO;
import DAO.UserDAO;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String email = (String) session.getAttribute("emailid");
        
        try {
            int userId = new UserDAO().getUserIdByEmail(email);
            DashboardDAO dashboard = new DashboardDAO();
            
            System.out.println("The user id = " + userId);
            Map<String, Object> userDetails = dashboard.getUserDetails(userId);
            
           
            request.setAttribute("username", userDetails.get("username"));
            request.setAttribute("income", userDetails.get("income")); 
            request.setAttribute("expense", userDetails.get("expense")); 
            request.setAttribute("balance", userDetails.get("balance"));
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
            dispatcher.forward(request, response);
            
            
        } catch (SQLException e) {
        	System.out.println("Exception");
        	response.sendRedirect("login.jsp");
            e.printStackTrace();
        }
    }
}
