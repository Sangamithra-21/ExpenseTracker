package ExpenseTracker;

import java.io.IOException;
import java.sql.SQLException;

import DAO.SignupDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
	
	private static final long serialversionUID = 1L;
	
	protected void doPost(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException 
	{
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String mobile = request.getParameter("phone_number");
		String emailid = request.getParameter("emailid");
		
		try {
			SignupDAO signup = new SignupDAO();
			if(signup.addUser(username,password,mobile,emailid))
			{
				response.sendRedirect("login.jsp");
			}
			else
			{
				request.setAttribute("errorMessage","Registration Failed. User may already exist.");
				request.getRequestDispatcher("signup.jsp").forward(request, response);
			}
		}
		catch(SQLException e) {
			response.getWriter().print("in selvet");
			e.printStackTrace();
			request.setAttribute("errorMessage", "Database error occured.Please try again.");
			request.getRequestDispatcher("signup.jsp").forward(request, response);
			
		}
	}

}
