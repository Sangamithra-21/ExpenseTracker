package ExpenseTracker;

import java.io.IOException;
import java.sql.SQLException;

import DAO.CategoryDAO;
import DAO.ExpenseDAO;
import DAO.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/addExpense")
public class AddExpenseServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String date = request.getParameter("date");
        String category = request.getParameter("category");
        String amount = request.getParameter("amount");
        String description = request.getParameter("source");  // Get the description (source)

        HttpSession session = request.getSession();
        String email = (String) session.getAttribute("emailid");

        try {
            UserDAO userDao = new UserDAO();
            int userId = userDao.getUserIdByEmail(email);


            CategoryDAO categoryDao = new CategoryDAO();
            int categoryId = categoryDao.getCategoryByName(category);

            // Corrected to pass the description to addExpense
            boolean isInserted = new ExpenseDAO().addExpense(userId, categoryId, date, amount, description);
            if (isInserted) {
            	
                response.sendRedirect("dashboard.jsp");
            } else {
                request.setAttribute("errorMessage", "Failed to add expense, please try again.");
                request.getRequestDispatcher("add_expense.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Failed to add expense, please try again.");
            request.getRequestDispatcher("add_expense.jsp").forward(request, response);
        }
    }
}
